</div>
</div>
<!-- Javascripts-->
<script src="<?= public_back_end_path('js/jquery-2.1.4.min.js'); ?>"></script>
<script src="<?= public_back_end_path('js/bootstrap.min.js'); ?>"></script>
<script src="<?= public_back_end_path('js/plugins/pace.min.js'); ?>"></script>
<script src="<?= public_back_end_path('js/main.js'); ?>"></script>