<script type="text/javascript" src="<?= public_back_end_path('js/plugins/jquery.dataTables.min.js'); ?>"></script>
<script type="text/javascript" src="<?= public_back_end_path('js/plugins/dataTables.bootstrap.min.js'); ?>"></script>
<script type="text/javascript">
    $('#sampleTable').DataTable();
</script>