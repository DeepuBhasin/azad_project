<?php include_once('header.php'); ?>
<!-- about section 
			================================================== -->
<section class=" about-section">
	<div class="container">
		<div class="row">
			<div class="col-md-12">
				<div class="about-post">
					<img src="upload/others/5.jpg" alt="">
					<h1>Why you should choose us</h1>
					<p><?= nl2br($aboutPageData['about_description']); ?></p>
				</div>
			</div>

		</div>
	</div>
</section>
<!-- End about section -->
<?php include_once('footer.php'); ?>